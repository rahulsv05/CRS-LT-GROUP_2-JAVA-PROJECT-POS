package com.crs.lt.exception;

public class AdminExceprion {

}
