package com.crs.lt.constant;

public class Constant {
    enum  Gender{
        MALE,
        FEMALE
    }


}
