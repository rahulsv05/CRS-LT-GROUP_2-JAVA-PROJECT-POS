package com.crs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrsLtGrp2SpringRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
